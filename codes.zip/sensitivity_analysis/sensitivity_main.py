import numpy as np
import torch
from torch.autograd import Variable

from greedy_coverage import set_func, marginal_vec, greedy
from greedy_submodular import GreedyOptimizer 

save = True

P = torch.tensor([
    [.4,.4,.0],
    [.0,.4,.2],
    [.0,.0,.2]])
P = Variable(P, requires_grad = True)

num_items, num_targets = P.shape
eps =.2
sample_size = 100
K = 2
w = torch.ones(num_targets)    

### Smoothed Greedy ###
n = num_items
softmax = torch.nn.Softmax(dim = -1)
sols = torch.zeros(sample_size, num_items)
sumlogps = torch.zeros(sample_size)
P.retain_grad()
for i in range(sample_size):
    S, sumlogp = [], 0
    sol = torch.zeros(n)
    U = range(n)
    for k in range(K):
        g = marginal_vec(S, P, w)
        if len(U) == 0: break
        p = softmax(g[U]/eps)
        v = np.random.choice(U, p = p.detach().numpy())
        vidx = int(np.where(U == v)[0])
        U = np.delete(U, vidx)
        S += [v]
        sumlogp = sumlogp + torch.log(p[vidx])
    print(S)
    sol[S] = 1
    sols[i] = sol
    sumlogps[i] = sumlogp
beta = sols.mean(axis = 0)
solsumlogp = torch.mv((sols - beta).T, sumlogps)/ sample_size    


grads = torch.zeros(n, n, num_targets)
for i in range(3):
    grads[i] = torch.autograd.grad(solsumlogp[i], P, retain_graph=True)[0]

if save:
    fname = 'Pmat_grads.npz'
    np.savez(fname, Pmat = P.detach().numpy(), grads = grads)
