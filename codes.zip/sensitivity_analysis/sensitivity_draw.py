import numpy as np
import itertools

import networkx as nx
from networkx.algorithms import bipartite

import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['ps.useafm'] = True
matplotlib.rcParams['pdf.use14corefonts'] = True
matplotlib.rcParams['text.usetex'] = True

path = 'Pmat_grads.npz'
P = np.load(path)['Pmat']
grads = np.load(path)['grads']
num_items, num_targets = np.shape(P)

N = range(num_items + num_targets)
U, V = N[:num_items], N[num_items:]
E = np.array(list(itertools.product(U, V)))

G = nx.Graph()
for i in N:
    if i in U: G.add_node(i, bipartite = 0, label = r'$v_{}$'.format(i + 1))
    else: G.add_node(i, bipartite = 1, label = r'$t_{}$'.format(i + 1 - num_items))
labels = nx.get_node_attributes(G, 'label')


plt.clf()
fig, ax = plt.subplots(figsize = (2,2.4))
ax.axis("off")

for e in E:
    i, j = e[0], e[1]
    G.add_edge(i, j, probability = P[i][j - num_items])
top = nx.bipartite.sets(G)[0]
pos = nx.bipartite_layout(G, top)
for i in N: pos[i][1] = - pos[i][1]

probs = np.array(list(nx.get_edge_attributes(G, 'probability').values()))
pidx2 = np.where(probs == .2)[0]
pidx4 = np.where(probs == .4)[0]
edges2 = list(E[pidx2])
edges4 = list(E[pidx4])

nx.draw_networkx_nodes(
    G = G,
    pos = pos, 
    node_size = 600,
    node_color = 'w',
    alpha = 1,
    linewidths = 0,
    ax = ax
)

nx.draw_networkx_labels(
    G = G, 
    pos = pos,
    node_size = 600,
    font_size = 20,
    labels = labels,
    ax = ax 
    )

nx.draw_networkx_nodes(
    G = G,
    pos = pos, 
    node_size = 600,
    node_color = 'gray',
    alpha = .4,
    linewidths = 0,
    ax = ax
)

nx.draw_networkx_edges(
    G = G,
    pos = pos,
    width = 9, 
    alpha = 1,   
    edgelist = edges4, 
    edge_color  = 'gray',
    ax = ax
) 

nx.draw_networkx_edges(
    G = G,
    pos = pos,
    width = 6, 
    alpha = 1,   
    edgelist = edges2, 
    edge_color  = 'gray',
    ax = ax
) 

fig.tight_layout(pad=0, w_pad=0, h_pad=0)
fig.savefig('prob.pdf', bbox_inches="tight")




vmax = np.max(abs(grads)) 
for idx in range(num_items):
    plt.clf()
    fig, ax = plt.subplots(figsize = (2,2.4)) 
    ax.axis("off")
    grad = grads[idx]

    G.remove_edges_from(E)
    for e in E:
        i, j = e[0], e[1]
        G.add_edge(i, j, color = grad[i][j - num_items])

    colors = np.array(list(nx.get_edge_attributes(G, 'color').values()))
    cidx   = np.argsort(colors)
    colors = colors[cidx]
    edges  = list(E[cidx])

    nx.draw_networkx_nodes(
        G = G,
        pos = pos, 
        nodelist = [idx],
        node_size = 1000,
        node_color = 'k',
        alpha = 1,
        linewidths = 0,
        ax = ax
    )

    nx.draw_networkx_nodes(
        G = G,
        pos = pos, 
        node_size = 600,
        node_color = 'w',
        alpha = 1,
        linewidths = 0,
        ax = ax
    )

    nx.draw_networkx_labels(
        G = G, 
        pos = pos,
        node_size = 600,
        font_size = 20,
        labels = labels,
        ax = ax 
        )

    nx.draw_networkx_nodes(
        G = G,
        pos = pos, 
        node_size = 600,
        node_color = 'gray',
        alpha = .4,
        linewidths = 0,
        ax = ax
    )

    nx.draw_networkx_edges(
        G = G,
        pos = pos,
        width = 10, 
        alpha = .95,   
        edgelist = edges, 
        edge_color = colors,
        edge_cmap = plt.cm.coolwarm,
        edge_vmin = - vmax, 
        edge_vmax =   vmax,
        ax = ax
    ) 

    fig.tight_layout(pad=0, w_pad=0, h_pad=0)
    fig.savefig('grad{}.pdf'.format(idx+1), bbox_inches="tight")


plt.clf()
cvals = np.linspace(-vmax, vmax, 100)
xlabel = [-.8, -.4, 0, .4, .8]
label_idx = [np.argmin(abs(cvals - x)) for x in xlabel]
cvals = np.vstack((cvals, cvals))

fig, ax = plt.subplots(figsize = (2.4, 1))
ax.imshow(cvals, aspect=3, cmap=plt.cm.coolwarm) 
ax.set_xticks(label_idx)
ax.set_xticklabels([r'${}$'.format(x) for x in xlabel], fontsize = 15)
ax.set_yticks([])
plt.xticks(rotation = -90)
fig.tight_layout(pad=0, w_pad=0, h_pad=0)
fig.savefig('cbar.pdf', bbox_inches="tight")
