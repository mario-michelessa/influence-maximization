import torch
import torch.nn as nn
import numpy as np
from functools import partial
from numba import jit

def make_dsf(num_items, num_layers, intermediate_size):
    activation_fn = nn.Sigmoid
    if num_layers > 1:        
        net_layers = [nn.Linear(num_items, intermediate_size), activation_fn()]
        for hidden in range(num_layers-2):
            net_layers.append(nn.Linear(intermediate_size, intermediate_size))
            net_layers.append(activation_fn())
        net_layers.append(nn.Linear(intermediate_size, 1))
        net_layers.append(activation_fn())
        return nn.Sequential(*net_layers)
    else:
        return nn.Sequential(nn.Linear(num_items, 1), activation_fn())

def set_func(S, w, P):
    w = torch.Tensor(w)
    s = torch.zeros(P.shape[0])
    s[S] = 1
    return float(torch.dot(w, 1 - torch.prod(1 - (s*P.T).T, axis = 0)))


def marginal_vec(S, w, P):
    w = torch.Tensor(w)
    s = torch.zeros(P.shape[0])
    s[S] = 1
    sc = torch.ones_like(s) - s
    return sc * torch.mv(P, w * torch.prod(1 - (s*P.T).T, axis = 0))    


def oracle(S, n, num_partitions, K):
    s = torch.zeros(n)
    s[S] = 1
    s_mat = s.view(num_partitions, -1)
    partition_size = s_mat.shape[1]
    out, l, u = [], 0, partition_size
    for i in range(num_partitions):
        if sum(s_mat[i]) < K: out += list(set(range(l, u)) - set(S))
        l += partition_size
        u += partition_size
    return out

def rand_feasible(n, num_partitions, K):
    partition_size = int(n / num_partitions)
    out, l, u = [], 0, partition_size
    for i in range(num_partitions):
        out += list(np.random.choice(range(l, u), K, replace = False))
        l += partition_size
        u += partition_size
    return out

class GreedyOptimizer():
    
    def __init__(self, set_func, marginal_vec, oracle, n, sample_size, eps, beta):
        self.set_func     = set_func
        self.marginal_vec = marginal_vec
        self.oracle       = oracle
        self.n            = n
        self.sample_size  = sample_size
        self.eps          = eps
        self.beta         = beta
        self.softmax      = torch.nn.Softmax(dim = -1)

    def sgreedy(self, DeepSF):
        vals = torch.zeros(self.sample_size)
        sumlogps = torch.zeros_like(vals)
        for i in range(self.sample_size):
            S, sumlogp = [], 0
            s = torch.zeros(self.n)
            U = range(self.n)
            while True:
                s.data[S] = 1
                s_add_mat = (s.repeat(self.n, 1) + torch.eye(self.n)).clamp(0, 1)
                g = DeepSF(s_add_mat) - DeepSF(s)
                prob = self.softmax((g[U].view(-1)/self.eps))
                v = np.random.choice(U, p = prob.detach().numpy())
                vidx = int(np.where(U == v)[0])
                S += [v]
                U = self.oracle(S)
                if len(U) == 0: break
                sumlogp = sumlogp + torch.log(prob[vidx])    
            sumlogps[i] = sumlogp
            vals[i] = self.set_func(S)
        beta = vals.mean() if self.beta else self.beta
        fsumlogp = torch.dot(vals - beta, sumlogps) / self.sample_size
        return fsumlogp
    
    def greedy(self, DeepSF):
        val = 0
        S = []
        s = torch.zeros(self.n)
        U = range(self.n)
        while True:
            s.data[S] = 1
            s_add_mat = (s.repeat(self.n, 1) + torch.eye(self.n)).clamp(0, 1)
            g = DeepSF(s_add_mat) - DeepSF(s)
            v = U[int(torch.argmax(g[U].view(-1)))]
            if v not in S: S += [v]
            val += g[v]
            U = self.oracle(S)
            if len(U) == 0: return val, S
        
    def true_greedy(self):
        val = 0
        S = []
        U = range(self.n)
        while True:
            g = self.marginal_vec(S)
            v = U[int(torch.argmax(g[U].view(-1)))]
            if v not in S: S += [v]
            val += g[v]
            U = self.oracle(S)
            if len(U) == 0: return val, S
