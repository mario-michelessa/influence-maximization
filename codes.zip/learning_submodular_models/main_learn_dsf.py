import os
import torch
import torch.nn as nn
import numpy as np
from functools import partial
from numba import jit

from learn_dsf_tools import set_func, marginal_vec, oracle, rand_feasible, make_dsf, GreedyOptimizer

### instances ###
f = open('brunson_corporate-leadership/out.brunson_corporate-leadership_corporate-leadership')  
data = f.readlines()
f.close()

lines = []
for line in data[2:]:
    line = list(map(int, line.split(' ')[:-1]))
    line[0], line[1] = line[0] - 1, line[1] - 1
    lines.append(line)

num_items = 20
num_targets = 24
num_partitions = 2
K = 2

P = torch.zeros([num_items, num_targets])
for line in lines:
    i, j = line[0], line[1]
    P[i, j] = 1

w_true = torch.tensor([1 if i % 2 == 0 else .1 for i in range(num_targets)]).float()
noise = False

### deep submodular function model ###
num_layers = 2
intermediate_size = 50
def init_weights(m):
    if type(m) == nn.Linear:
        m.weight.data.uniform_(.0, .01)
        m.bias.data.uniform_(.0, .01)


### smoothed greedy, greedy, and random ###
n = num_items
sample_size = 10
beta = 1
eps = .02

def S_noisy_set_func(S, S_set_func):    
    return S_set_func(S) + np.random.randn()

S_set_func = partial(set_func, w = w_true, P = P)
if noise: 
    S_set_func = partial(S_noisy_set_func, S_set_func = S_set_func)
S_marginal_vec = partial(marginal_vec, w = w_true, P = P)
S_oracle = partial(oracle, n = n, num_partitions = num_partitions, K = K)
go = GreedyOptimizer(S_set_func, S_marginal_vec, S_oracle, n, sample_size, eps, beta)

sgreedy_results = [] # seed, t, model, true
random_results  = [] 
greedy_results  = [] 

grd_val, grd_sol = go.true_greedy()
grd_val = float(grd_val)

for seed in range(1):

    rnd_sol = rand_feasible(n, num_partitions, K)
    rnd_val = set_func(rnd_sol, w_true, P)

    DeepSF = make_dsf(num_items, num_layers, intermediate_size)    
    DeepSF.apply(init_weights)
    optimizer = torch.optim.Adam(DeepSF.parameters(), lr = 1e-3)

    t = 0
    val, sol = go.greedy(DeepSF)
    sgreedy_results.append([seed, t, float(val.detach().numpy()), set_func(sol, w_true, P)])
    random_results.append([seed, t, rnd_val, rnd_val])
    greedy_results.append([seed, t, grd_val, grd_val])

    for t in range(1, 21):
        neg_fsumlogp = - go.sgreedy(DeepSF)
        neg_fsumlogp.backward()
        optimizer.step()
        val, sol = go.greedy(DeepSF)
        sgreedy_results.append([seed, t, float(val.detach().numpy()), set_func(sol, w_true, P)])
        random_results.append([seed, t, rnd_val, rnd_val])
        greedy_results.append([seed, t, grd_val, grd_val])

    print(seed)
    print(np.array(sgreedy_results[seed*(t+1) + 1:]))
    print(rnd_val, grd_val)


sgreedy_results = np.array(sgreedy_results) 
random_results  = np.array(random_results ) 
greedy_results  = np.array(greedy_results ) 


### save results ###
path = 'results/'

fname = 'grd.npz'
if os.path.exists(path + fname) == False:
    np.savez(path + fname, res = greedy_results)

fname = 'rnd.npz'
if os.path.exists(path + fname) == False:
    np.savez(path + fname, res = random_results)

if noise: path += 'noise_'
fname = 'sgrd_b{}_N{}.npz'.format(beta, sample_size)
if os.path.exists(path + fname) == False:
    np.savez(path + fname, res = sgreedy_results)