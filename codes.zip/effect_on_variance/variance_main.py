import numpy as np
import torch
from torch.autograd import Variable

from greedy_coverage import set_func, marginal_vec, greedy
from greedy_submodular import GreedyOptimizer 

import pandas as pd

save = True

P = torch.tensor([
    [.4,.4,.0],
    [.0,.4,.2],
    [.0,.0,.2]])
P = Variable(P, requires_grad = True)

num_items, num_targets = P.shape
K = 2
w = torch.ones(num_targets)

### Smoothed Greedy ###
n = num_items
softmax = torch.nn.Softmax(dim = -1)

eps_vals = list(np.arange(.1, 1.1, .1))
#eps_vals[0] = .01

data = []
for is_vr, sample_size in [(0, 50), (0, 100), (1, 50), (1, 100)]: 
    for i in range(len(eps_vals)):
        eps = eps_vals[i]

        sols = torch.zeros(sample_size, num_items)
        sumlogps = torch.zeros(sample_size)

        P.retain_grad()
        for i in range(sample_size):
            S, sumlogp = [], 0
            sol = torch.zeros(n)
            U = range(n)
            for k in range(K):
                g = marginal_vec(S, P, w)
                if len(U) == 0: break
                p = softmax(g[U]/eps)
                v = np.random.choice(U, p = p.detach().numpy())
                vidx = int(np.where(U == v)[0])
                U = np.delete(U, vidx)
                S += [v]
                sumlogp = sumlogp + torch.log(p[vidx])
            sol[S] = 1
            sols[i] = sol
            sumlogps[i] = sumlogp


        beta = sols.mean(axis = 0) * is_vr

        trial_solsumlogps = torch.zeros(sample_size, num_items)
        for i in range(sample_size):
            trial_solsumlogps[i] = (sols[i] - beta) * sumlogps[i]


        trial_J = torch.zeros(sample_size, n, n, num_targets)
        for i in range(sample_size):
            J = torch.zeros(n, n, num_targets)
            for j in range(n):
                J[j] = torch.autograd.grad(trial_solsumlogps[i][j], P, retain_graph=True)[0]
            trial_J[i] = J

        trial_J_vec = trial_J.view(sample_size, -1)
        variance = torch.norm(trial_J_vec - torch.mean(trial_J_vec, axis = 0))**2/sample_size

        data.append([is_vr, sample_size, eps, float(variance)])

df = pd.DataFrame(data, columns = ['VR', 'N', 'eps', 'variance'])

if save:
    df.to_csv('variance_sol.csv', index = False)