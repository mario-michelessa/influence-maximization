# Differentiable Greedy Algorithm for Monotone Submodular Maximization: Guarantees, Gradient Estimators, and Applications

The implementation of algorithms used in ***Differentiable Greedy Algorithm for Monotone Submodular Maximization: Guarantees, Gradient Estimators, and Applications***. 

## Requirements
To install requirements: 
```
pip install -r requirements.txt
```
## Empirical study on variance (Section 3.1)

Codes are provided in `effect_to_variance` directory. 
To produce the result, run
```
python variance_main.py
```
The result will be saved as `variance_sol.csv`. 


## Sensitivity analysis (Section 5.1)
Codes are provided in `sensitivity_analysis` directory. 

To compute the estimator of the Jacobian, run this command: 
``` 
python sensitivity_main.py
```
The results will be saved as `Pmat_grads.npz`. 

To visualize the results, run this command: 
```
python sensitivity_draw.py
```
- `prob.pdf` visualizes the link probabilities. 
- `grad1-3.pdf` visualize the entries of the estimated Jacobian matrices. 
- `cbar.pdf` indicates the color bar of the entries. 






## Decision-focused learning (Section 5.2)

Codes are provided in `decision_focused_learning` directory. 

### Instances

For creating the instances, 
1. get [MovieLens 100K dataset](https://grouplens.org/datasets/movielens/100k/), 
2. put `u.item`, `u.user`, and `u.data` files in `ml-100k` directory, and  
3. run this command: 
    ```
    python make_movielens_instances.py
    ```
This will create *.npz* instance files in `instances` directory. 

### Training and evaluation

For training and evaluating our method, run, for example, this command: 
```
python grd_main.py --k 5 --eps .2 --beta 1 --sample 10
```
This executes our algorithm with the entropy regularization. Below is the detail of each option: 
- `---k 5`: the upper bound, *K*, on the cardinality is 5. 
- `--eps .2`: the multiplicative constant, *epsilon*, of the entropy regularization is equal to 0.2. 
- `--beta 1`: when estimating gradients, the variance is reduced with the baseline correction method (set `--beta 0` to turn off). 
- `--sample 10`: *N* = 10 samples are used for estimating loss function values and gradients. 

The results will be saved as `k5_grd_b1_s10.npz` in `results` directory. 

Analogously, the 

- continuous relaxation method, 
- two-stage method, and 
- random method

can be trained and evaluated as follows, respectively: 
```
python cnt_main.py --k 5
```
```
python two_main.py --k 5
```
```
python rnd_main.py --k 5
```

### Results

When *K* = 5, the results will become, for example, as follows (excerpted from Table 1 in the paper):
| Method     | Training    | Test       |
| ---------- |-------------| -----------|
|  VR-SG-10  | 35.2 ± 6.1  | 33.7 ± 6.2 |
| Continuous | 24.0 ± 4.5  | 23.2 ± 4.9 |
| Two-stage  | 17.3 ± 1.2  | 17.3 ± 2.1 |
| Random     | 17.5 ± 1.5  | 17.6 ± 2.2 |



## Learning of submodular models with oracle queries (Appendix E.2)

Codes are provided in `learning_submodular_models` directory. 

### Instances

For creating instances used in the experiments, 
1. get [Corporate leadership dataset of KONECT](http://konect.uni-koblenz.de/networks/brunson_corporate-leadership) and 
2. put `out.bruson_corporate-leadership_corporate-leadership` file in `bruson_corporate-leadership` directory.  

### Evaluation

To produce the reuslts, run this command:
```
python main_learn_dsf.py
```
This will produce the results for the case where 
we let *N* = 10 and the variance is reduced with the baseline correction. 

For obtaining results of the other settings, 
change the following variables in the code: 

- `beta (= 0 or 1)` to turn on/off the baseline correction,  
- `sample_size (= N)` to specify the sample size, *N*, and  
- `noise (= True or False)` for noisy/noise-free settings.  



### Results
Results will be saved in `results` directory. 
See, the figures in **Appendix E.2** for visualized results. 

## DIfferentiable stochastic greedy algorithm (Appendix F.3)

Codes are provided in `stochastic_greedy` directory. 

### Instances

Create MovieLens instances with `make_movielens_instances.py` in the same manner as that of [Decision-focused learning (Section 5.2)](#decision-focused-learning-section-52). 

### Training and evaluation

For training and evaluating the method, run, for example, this command: 
```
python stochastic_main.py --nk 10
```
This uses the stochastic smoothed greedy algorithm that samples (up to) 10 elements in each iteration. 
The sample size, *n_k*, in each iteration of the stochastic greedy algorithm can be changed with `--nk` option.   

### Results

The results will be saved as `nk10.npz` in `results` directory. 
See, the figures in **Appendix F.3** for visualized results. 

